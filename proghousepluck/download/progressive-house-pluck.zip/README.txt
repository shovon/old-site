Unzip the progressive-house-pluck.xpf file over to your LMMS' presets folder,
which is found in

- /home/your_username/lmms/presets on Linux, and
- C:\Users\your_username\lmms\presets on Windows.

And don't worry, you are free to use it anywhere. :)